import math
from math import log

def log2(x):
    return log(x)/log(2)

def log3(x):
    return log(x)/log(3)

def log4(x):
    return log(x)/log(4)

def log5(x):
    return log(x)/log(5)

def log6(x):
    return log(x)/log(6)

def log7(x):
    return log(x)/log(7)

def log8(x):
    return log(x)/log(8)

def log9(x):
    return log(x)/log(9)